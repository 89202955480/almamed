<?php

return array(
    'code' => 'MUR',
    'sign' => '₨',
    'sign_position' => 0,
    'sign_delim' => ' ',
    'title' => 'Mauritian rupee',
    'name' => array(
        array('rupee', 'rupees'),
    ),
    'frac_name' => array(
        array('cent', 'cents'),
    )
);