<?php 
$message = "You don't have permission to access requested URL on this server.";
include('error.php');
 