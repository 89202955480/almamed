<?php 

return array(
    'name' => 'Webasyst',
    'prefix' => 'webasyst',
    'analytics' => true,
    'version' => '1.4.2',
    'critical'=>'1.4.2',
    'vendor' => 'webasyst',
);
