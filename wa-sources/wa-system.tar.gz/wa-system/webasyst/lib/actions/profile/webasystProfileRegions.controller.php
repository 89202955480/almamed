<?php

class webasystProfileRegionsController extends webasystBackendRegionsController
{
}

