<?php
waFiles::delete('wa-system/util/waLocalizedCollection.php', true);
